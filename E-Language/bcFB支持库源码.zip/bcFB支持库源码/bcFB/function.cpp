#include "elib.h"
#include <ByteStr.hpp>
//#include <coutlog.hpp>

/*
������ʵ�ֶ���Ҫ�����ں�������Ա㾲̬�Ͷ�̬�ⶼ��ʹ�ã���ExecuteCommand��Commands��ֻ�趨���ں�����湩��̬��ʹ�á�
pRetData �������ָ�롣����ӦCMD_INFO��m_dtRetTypeΪ_SDT_NULL���������޷���ֵ��ʱ��pRetData��Ч��
iArgCount ������������
pArgInf ��������ָ��
*/

//void MsgA(const char* format, ...)
//{
//	static HANDLE h = GetProcessHeap();
//	char* strBuf = (char*)HeapAlloc(h, 0, 0x1000);
//	va_list vlArgs;
//	va_start(vlArgs, format);
//	_vsnprintf(strBuf, 0x1000-1, format, vlArgs);
//	va_end(vlArgs);
//	strcat(strBuf, "\n");
//	MessageBoxA(0, strBuf, 0, 0);
//	HeapFree(h, 0, strBuf);
//}

EXTERN_C
void bcfb_jzjj(PMDATA_INF pRetData, INT iArgCount, PMDATA_INF pArgInf)
{
	LPBYTE pData; INT nDataSize;
	pData = (LPBYTE)pArgInf[0].m_pAryData + 4*2;
	nDataSize = *(LPINT)(pData - 4);
	StrA out = jzjj(Bytes(pData, nDataSize));
	pRetData->m_pText = CloneTextData(out, out.size+1);
}

inline byte* FBgetp(byte* �������, int ָ��i)
{
	return �������+(*(int*)(�������+4*(ָ��i + 1)));
}
inline byte* FBgetp(byte* �������, int ָ��i, int& size)
{
	byte* p = �������+(*(int*)(�������+4*(ָ��i + 1)));
	byte* p2 = �������+(*(int*)(�������+4*(ָ��i + 2)));
	size = p2-p; return p;
}
inline int FBgeti(byte* �������, int ָ��i)
{
	int size, r = 0;
	memcpy(&r, FBgetp(�������, ָ��i, size), size);
	return r;
}
inline __int64 FBgetl(byte* �������, int ָ��i)
{
	return *(__int64*)FBgetp(�������, ָ��i);
}
inline int _���鴦��_ȷ����С(int type, int* arr)
{
	int size = *(arr+1);
	if (type == SDT_BYTE || type==SDT_BOOL){
	} else if (type == SDT_SHORT){
		size *= 2;
	} else if (type == SDT_INT || type==SDT_FLOAT){
		size *= 4;
	} else if (type==SDT_INT64 || type==SDT_DOUBLE){
		size *= 8;
	} else if (type == SDT_BIN){
		int n = size; arr = arr+2; size = 4*(1+n); //ĩβ����ָ��
		for (int i = 0; i<n; i++)
		{
			if (arr[i])size += *(((int*)arr[i])+1);
		}
	} else if (type == SDT_TEXT){
		int n = size; arr = arr+2; size = 4*(1+n); //ĩβ����ָ��
		for (int i = 0; i<n; i++)
		{
			size += strlen((char*)(arr[i]));
		}
	}
	//MsgA("%d", size);
	return 4+size+1; //β�����һ���ֽ�����ȷ������
}
inline int _���鴦��_��ʼ���(int type, int* arr, BYTE* pbuf)
{
	int arrsize = *(arr+1); *(int*)pbuf = arrsize; //��ͷд���ܸ���
	pbuf += 4;
	if (type == SDT_BYTE){
		memcpy(pbuf, arr+2, arrsize); *(pbuf+arrsize) = -1;
	} else if (type == SDT_SHORT){
		arrsize *= 2; memcpy(pbuf, arr+2, arrsize); *(pbuf+arrsize) = -2;
	} else if (type == SDT_INT || type==SDT_FLOAT){
		arrsize *= 4; memcpy(pbuf, arr+2, arrsize);
		*(pbuf+arrsize) = type==SDT_FLOAT ? 'f' : -4;
	} else if (type==SDT_INT64 || type==SDT_DOUBLE){
		arrsize *= 8; memcpy(pbuf, arr+2, arrsize);
		*(pbuf+arrsize) = type==SDT_DOUBLE ? 'd' : -8;
	} else if (type == SDT_BIN){
		int n = arrsize; arrsize = 4*(2+n); //count��ĩβ����ָ��
		BYTE* rp = pbuf-4; arr = arr+2;
		for (int i = 0; i<n; i++)
		{
			*(int*)pbuf = arrsize;
			if (arr[i]){
				int size = *(((int*)arr[i])+1);
				memcpy(rp+arrsize, ((int*)arr[i])+2, size); //�ֽڼ�buf����
				arrsize += size;
			}
			pbuf += 4;
		}
		*(int*)pbuf = arrsize;
		*(rp+arrsize) = 'b'; arrsize -= 4;
	} else if (type == SDT_TEXT){
		int n = arrsize; arrsize = 4*(2+n); //count��ĩβ����ָ��
		BYTE* rp = pbuf-4; arr = arr+2;
		for (int i = 0; i<n; i++)
		{
			*(int*)pbuf = arrsize;
			if (arr[i]){
				int size = strlen((char*)(arr[i]));
				memcpy(rp+arrsize, (char*)arr[i], size); //�ֽڼ�buf����
				arrsize += size;
			}
			pbuf += 4;
		}
		*(int*)pbuf = arrsize;
		*(rp+arrsize) = 's'; arrsize -= 4;
	} else if (type==SDT_BOOL){
		arr += 2; *(pbuf+arrsize) = 1;
		for (int i = 0; i<arrsize; i++)*(pbuf++) = *(arr++);
	}
	return 4+arrsize+1;
}

EXTERN_C
void bcfb_FB(PMDATA_INF pRetData, INT iArgCount, PMDATA_INF pArgInf)
{
	int k = (iArgCount + 2) * 4, m = k;
	Bytes out(m);
	BYTE* p = out.buf;
	*((int*)p) = iArgCount; //��������
	for (int i = 0; i < iArgCount; i++)
	{
		DATA_TYPE dtDataType = pArgInf[i].m_dtDataType;
		p = p+4;
		*((int*)p) = m;
		if (dtDataType == SDT_BIN){
			m = m+*((LPINT)(pArgInf[i].m_pAryData)+1);
		} else if (dtDataType == SDT_TEXT){
			m = m+strlen(pArgInf[i].m_pText);
		} else if (dtDataType == SDT_INT || dtDataType==SDT_FLOAT){
			m = m+4;
		} else if (dtDataType == SDT_BYTE || dtDataType==SDT_BOOL){
			m = m+1;
		} else if (dtDataType == SDT_SHORT){
			m = m+2;
		} else if (dtDataType==SDT_INT64 || dtDataType==SDT_DOUBLE){
			m = m+8;
		} else if ((dtDataType&DT_IS_ARY)==DT_IS_ARY){
			m = m+_���鴦��_ȷ����С(dtDataType&(~DT_IS_ARY), (int*)pArgInf[i].m_pAryData);
		}
	}
	p = p+4;
	*((int*)p) = m;
	out = out + Bytes(m - k);
	p = out.buf+k;
	for (int i = 0; i<iArgCount; i++)
	{
		DATA_TYPE dtDataType = pArgInf[i].m_dtDataType;
		int size;
		if (dtDataType == SDT_BIN){
			LPINT pBuf = (LPINT)pArgInf[i].m_pAryData;
			size = *(pBuf+1); memcpy(p, pBuf+2, size);
		} else if (dtDataType == SDT_TEXT){
			size = strlen(pArgInf[i].m_pText); memcpy(p, pArgInf[i].m_pText, size);
		} else if (dtDataType == SDT_INT || dtDataType==SDT_FLOAT){
			size = 4; memcpy(p, &pArgInf[i].m_int, size);
		} else if (dtDataType == SDT_BYTE){
			size = 1; memcpy(p, &pArgInf[i].m_int, size);
		} else if (dtDataType == SDT_SHORT){
			size = 2; memcpy(p, &pArgInf[i].m_int, size);
		} else if (dtDataType==SDT_INT64 || dtDataType==SDT_DOUBLE){
			size = 8; memcpy(p, &pArgInf[i].m_int, size);
		} else if ((dtDataType&DT_IS_ARY)==DT_IS_ARY){
			size = _���鴦��_��ʼ���(dtDataType&(~DT_IS_ARY), (int*)pArgInf[i].m_pAryData, p);
		} else if (dtDataType==SDT_BOOL){
			size = 1; *p = pArgInf[i].m_bool!=0;
		}
		p = p+size;
	}
	pRetData->m_pBin = CloneBinData(out.buf, out.size);
}

void _�������_��������(int* arr)
{
	int* r = arr; int arrsize = *(arr+1); arr += 2;
	for (int i = 0; i<arrsize; i++)
	{
		MFree((void*)*(arr++));
	}
	MFree(r);
}

EXTERN_C
void bcfb_deFB(PMDATA_INF pRetData, INT iArgCount, PMDATA_INF pArgInf)
{
	byte* buf; int size;
	//coutlogA("jiebao",iArgCount,pArgInf[0].m_dtDataType);

	if (pArgInf[0].m_dtDataType==SDT_BIN){
		buf = pArgInf[0].m_pBin+8;
	} else if (pArgInf[0].m_dtDataType==SDT_SUB_PTR){
		buf = pArgInf[0].m_pBin;
	} else{
		buf = pArgInf[0].m_pBin;
	}

	for (int i = 1; i<iArgCount; i++)
	{
		DATA_TYPE dtDataType = pArgInf[i].m_dtDataType;
		if (dtDataType == SDT_INT || dtDataType==SDT_FLOAT){
			memcpy(pArgInf[i].m_pByte, FBgetp(buf, i-1), 4);
		} else if (dtDataType == SDT_SHORT){
			memcpy(pArgInf[i].m_pByte, FBgetp(buf, i-1), 2);
		} else if (dtDataType == SDT_BYTE){
			memcpy(pArgInf[i].m_pByte, FBgetp(buf, i-1), 1);
		} else if (dtDataType==SDT_INT64 || dtDataType==SDT_DOUBLE){
			memcpy(pArgInf[i].m_pByte, FBgetp(buf, i-1), 8);
		} else if (dtDataType==SDT_TEXT){
			MFree(*pArgInf[i].m_ppText);
			*pArgInf[i].m_ppText = CloneTextData((char*)FBgetp(buf, i-1, size), *&size);
		} else if (dtDataType==SDT_BIN){
			MFree(*pArgInf[i].m_ppBin);
			*pArgInf[i].m_ppBin = CloneBinData((LPBYTE)FBgetp(buf, i-1, size), *&size);
		} else if ((dtDataType&DT_IS_ARY)==DT_IS_ARY){
			dtDataType = dtDataType & ~DT_IS_ARY; int _size;
			byte* _buf = FBgetp(buf, i-1, _size);
			int count = *(int*)_buf;
			if (dtDataType==SDT_TEXT){
				_�������_��������((int*)*pArgInf[i].m_ppAryData);
				char** pDest = (char**)(*pArgInf[i].m_ppAryData = MMalloc(8+4*count));
				*pDest = (char*)1; *(++pDest) = (char*)count; pDest++;
				for (int k = 0; k<count; k++, pDest++)
				{
					*pDest = CloneTextData((char*)FBgetp(_buf, k, size), *&size);
				}
			} else if (dtDataType==SDT_BIN){
				_�������_��������((int*)*pArgInf[i].m_ppAryData);
				char** pDest = (char**)(*pArgInf[i].m_ppAryData = MMalloc(8+4*count));
				*pDest = (char*)1; *(++pDest) = (char*)count; pDest++;
				for (int k = 0; k<count; k++, pDest++)
				{
					*pDest = (char*)CloneBinData((LPBYTE)FBgetp(_buf, k, size), *&size);
				}
			} else{
				MFree(*pArgInf[i].m_ppAryData); LPBYTE p;
				_size = _size-1; //�ٵ�ĩβ��1�ֽڱ�ʾ���͵�
				if (dtDataType==SDT_BOOL){ //����������FB��1�ֽ�������ԭ�������Ե�4�ֽ�
					_size -= 4; LPINT pb = (int*)(p = (LPBYTE)MMalloc(8+_size*4));
					*(pb+1) = _size; pb += 2; _buf += 4;
					for (int i = 0; i<_size; i++)pb[i] = *(_buf++);
				} else{
					p = (LPBYTE)MMalloc(4+_size); //�����Ե��������һ��ά��
					memcpy(p+4, _buf, _size);
				}
				*(int*)p = 1; *pArgInf[i].m_ppBin = p;
			}
		} else if (dtDataType==SDT_SUB_PTR){
			//MsgA("����hack�ֶΣ�����ֵ��ָ����������ڴ�����͸���");
			*pArgInf[i].m_pInt = (int)FBgetp(buf, i-1);
		} else if (dtDataType==SDT_BOOL){
			*pArgInf[i].m_pBool = (*FBgetp(buf, i-1))!=0;
		}
	}
}

EXTERN_C
void bcfb_pFB(PMDATA_INF pRetData, INT iArgCount, PMDATA_INF pArgInf)
{
	pRetData->m_int = pArgInf->m_int+8;
}

EXTERN_C
void bcfb_pFB_n(PMDATA_INF pRetData, INT iArgCount, PMDATA_INF pArgInf)
{
	pRetData->m_int = *pArgInf->m_pInt;
}

EXTERN_C
void bcfb_pFB_p(PMDATA_INF pRetData, INT iArgCount, PMDATA_INF pArgInf)
{
	pRetData->m_int = (int)FBgetp((byte*)pArgInf[0].m_pInt, pArgInf[1].m_int-1);
}


EXTERN_C
void bcfb_gFB(PMDATA_INF pRetData, INT iArgCount, PMDATA_INF pArgInf)
{
	int size;
	byte* p = pArgInf[0].m_dtDataType==SDT_INT ? (byte*)pArgInf[0].m_int
		: (byte*)(pArgInf[0].m_pBin+8);
	p = FBgetp(p, pArgInf[1].m_int, size);
	pRetData->m_pBin = CloneBinData((LPBYTE)p, size);
}

EXTERN_C
void bcfb_gFBi(PMDATA_INF pRetData, INT iArgCount, PMDATA_INF pArgInf)
{
	byte* p = pArgInf[0].m_dtDataType==SDT_INT ? (byte*)pArgInf[0].m_int
		: (byte*)(pArgInf[0].m_pBin+8);
	pRetData->m_int = FBgeti(p, pArgInf[1].m_int);
}
EXTERN_C
void bcfb_gFBb(PMDATA_INF pRetData, INT iArgCount, PMDATA_INF pArgInf)
{
	byte* p = pArgInf[0].m_dtDataType==SDT_INT ? (byte*)pArgInf[0].m_int
		: (byte*)(pArgInf[0].m_pBin+8);
	pRetData->m_bool = *(bool*)FBgetp(p, pArgInf[1].m_int);
}

EXTERN_C
void bcfb_gFBf(PMDATA_INF pRetData, INT iArgCount, PMDATA_INF pArgInf)
{
	byte* p = pArgInf[0].m_dtDataType==SDT_INT ? (byte*)pArgInf[0].m_int
		: (byte*)(pArgInf[0].m_pBin+8);
	int size;
	p = FBgetp(p, pArgInf[1].m_int, size);
	if(size==4){
		pRetData->m_double = *(float*)p;
	}else{
		pRetData->m_double = *(double*)p;
	}
}

EXTERN_C
void bcfb_gFBs(PMDATA_INF pRetData, INT iArgCount, PMDATA_INF pArgInf)
{
	int size;
	byte* p = pArgInf[0].m_dtDataType==SDT_INT ? (byte*)pArgInf[0].m_int
		: (byte*)(pArgInf[0].m_pBin+8);
	p = FBgetp(p, pArgInf[1].m_int, size);
	pRetData->m_pText = CloneTextData((char*)p, size);
}

EXTERN_C
void bcfb_gFB_n(PMDATA_INF pRetData, INT iArgCount, PMDATA_INF pArgInf)
{
	char* p = pArgInf[0].m_dtDataType==SDT_INT ? (char*)pArgInf[0].m_int
		: (char*)(pArgInf[0].m_pBin+8);
	pRetData->m_int = *p;
}

EXTERN_C
void bcfb_gFB_p(PMDATA_INF pRetData, INT iArgCount, PMDATA_INF pArgInf)
{
	byte* p = pArgInf[0].m_dtDataType==SDT_INT ? (byte*)pArgInf[0].m_int
		: (byte*)(pArgInf[0].m_pBin+8);
	p = FBgetp(p, pArgInf[1].m_int);
	pRetData->m_int = (int)p;
}

EXTERN_C
void bcfb_gFBl(PMDATA_INF pRetData, INT iArgCount, PMDATA_INF pArgInf)
{
	byte* p = pArgInf[0].m_dtDataType==SDT_INT ? (byte*)pArgInf[0].m_int
		: (byte*)(pArgInf[0].m_pBin+8);
	pRetData->m_int64 = FBgetl(p, pArgInf[1].m_int);
}