#include "stdafx.h"
#include "../bcFB/function.cpp"

void main()
{
	MDATA_INF r; MDATA_INF dat[1];
	dat[0].m_pText = "���hello";

	printf("%u,%u",SDT_SUB_PTR,SDT_INT);
	//bcFB_test2(&r,1,dat);
}